# my-gaming-website
<p> This is one of the gaming websites that i created with HTML and CSS that will greatly enhance your CSS skills if you practice to build it as closely as it is, you will improve your CSS skills without no doubt. </p>
  
<p> Try to pratice and achieve the same thing. if you get stuck in anyway, the source code is already provided. you could clone it and go through it if needed. </p>

# How to Incorporate Font awesome Icon locally on your Computer 

1. grab the Webfonts FOlder and place it in your root project file
2. copy the all.min.css file and place it your head tag and link it up by using the <link> tag and reference it with all.min.css 
e.g <link rel="stylesheet" href="all.min.css">
4. after that you can make use of any icon in your project as long as you know the name of the icon you want to use. If you don't know the name of the icon that you want, you can head over to fontawesome.com and search for the icon you want to incoporate in your project
